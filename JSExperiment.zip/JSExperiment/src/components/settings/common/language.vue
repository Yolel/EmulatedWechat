<template>
    <div id="language">
        language设置
    </div>
</template>
<script>
    export default {}
</script>
<style>
</style>