<template>
    <div id="settings">
        settings
        <br>
        <router-link to="/self/settings/common">通用</router-link>
    </div>
</template>
<script>
    export default {}
</script>
<style>
    @import "../../assets/css/settings.css";
</style>